//
//  SENTSDK.h
//  SENTSDK
//
//  Created by Afees Lawal on 16.03.24.
//

#import <Foundation/Foundation.h>

//! Project version number for SENTSDK.
FOUNDATION_EXPORT double SENTSDKVersionNumber;

//! Project version string for SENTSDK.
FOUNDATION_EXPORT const unsigned char SENTSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SENTSDK/PublicHeader.h>


