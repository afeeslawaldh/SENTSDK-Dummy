//
//  Protobuf.h
//  Protobuf
//
//  Created by Afees Lawal on 16.03.24.
//

#import <Foundation/Foundation.h>

//! Project version number for Protobuf.
FOUNDATION_EXPORT double ProtobufVersionNumber;

//! Project version string for Protobuf.
FOUNDATION_EXPORT const unsigned char ProtobufVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Protobuf/PublicHeader.h>


