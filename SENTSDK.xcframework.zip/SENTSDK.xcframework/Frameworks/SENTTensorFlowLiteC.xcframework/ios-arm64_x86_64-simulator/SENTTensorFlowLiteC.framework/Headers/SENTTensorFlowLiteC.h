//
//  SENTTensorFlowLiteC.h
//  SENTTensorFlowLiteC
//
//  Created by Afees Lawal on 16.03.24.
//

#import <Foundation/Foundation.h>

//! Project version number for SENTTensorFlowLiteC.
FOUNDATION_EXPORT double SENTTensorFlowLiteCVersionNumber;

//! Project version string for SENTTensorFlowLiteC.
FOUNDATION_EXPORT const unsigned char SENTTensorFlowLiteCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SENTTensorFlowLiteC/PublicHeader.h>


