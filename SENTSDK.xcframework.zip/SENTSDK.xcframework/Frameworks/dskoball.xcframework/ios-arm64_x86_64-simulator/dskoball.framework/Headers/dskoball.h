//
//  dskoball.h
//  dskoball
//
//  Created by Afees Lawal on 16.03.24.
//

#import <Foundation/Foundation.h>

//! Project version number for dskoball.
FOUNDATION_EXPORT double dskoballVersionNumber;

//! Project version string for dskoball.
FOUNDATION_EXPORT const unsigned char dskoballVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <dskoball/PublicHeader.h>


